#HP_Ultra_Slim
HP PROBOOK  440 G3
14" | Intel Core i3-6100U @2.3GHz  @6th Gen | 8 Go DDR4 | SSD 128Go HDD 500 Go |