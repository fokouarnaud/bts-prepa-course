HP PROBOOK 11 EE TACTILE
11.6" | Intel Core i3 @ 2.3GHz @ 6th Gen | 4 Go | HDD 500 Go