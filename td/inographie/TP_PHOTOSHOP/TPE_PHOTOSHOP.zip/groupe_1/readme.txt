#Lenovo_Ultra_Slim_Tactile
Lenovo IdeaPad Flex 15D Tactile
15.6" Tactile | AMD E1-2  @6th Gen | 4 Go RAM | HDD 500 Go