HP PROBOOK 655 G1
15.6" | AMD  A6 @ 2.7~3.5 GHz  | 8 Go  | HDD 500 Go | 768mo dédié