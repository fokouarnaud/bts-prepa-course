#Dell_Ultra_Slim
Dell Latitude 3150
11.6" | Intel Quad Core @2.16GHz | 4 Go | HDD 500 Go