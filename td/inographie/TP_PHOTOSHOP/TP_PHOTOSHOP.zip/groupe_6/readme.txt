#Acer_aspire 
Acer aspire v15 nitro black 
Core i5-5th génération | CPU 2.4ghz | Ram 8go | HDD 1tb | NVIDIA GTX | 4g dédiée DDR3 